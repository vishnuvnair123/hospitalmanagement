<?php include("header.php");?>
<!-- Docter dashboard
  *Author:Ebin
-->
<div class="btd">
<form class="btf">
<button class="bt"><a href="doctview.php">View</a></button><br><br>
<button class="bt"><a href="patientview">View Patient Record</button><br><br>
<button class="bt"><a href="#">Manage appoinment</button><br><br>
<button class="bt"><a href="#">Remark</a></button><br><br>
</form>
</div>
<?php include("footer.php");?>
