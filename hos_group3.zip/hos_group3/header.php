<!DOCTYPE html>
<html>
<head><title>
</title>
<link rel="stylesheet" type="text/css" href="stylebin.css">
<style>

</style>
</head>
<body>
<div class="menubar">
<ul>
<li><a href="index(1).php">Home</a></li>
<li><a href="#">View</a>


<li><a href="index(1).php">Contact us</a></li>
<li><a href="patient_registration.php">Patient Registration</a></li>
<li><a href="index.php">Logout</a></li>
</ul>
</div>
