<?php include("header.php");?>
<div class="se">
<br>
<br>

<center>
<h1> SEARCH DOCTOR</h1>
<form method="post" action="search_docres.php">
    Specilization: 
	<select name="specialization" class="frm"> 
       <option value=""></option>
       <option value="psychiatrist">PSYCHIATRIST</option>
       <option value="Cardiologist">CARDIOLOGIST</option>
       <option value="Gynecologist">GYNECOLOGIST</option>
     </select><br><br>
   
       
	
	
  <input type="submit" name="submit" class="frm-btn"> </a>
  </form>
  </center>
 </div>    

<?php include("footer.php");?>