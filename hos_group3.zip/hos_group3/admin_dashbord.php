<?php include("header.php");?>
      <div class="btd">
         <button class="bt"><a href="docterview.php" class="link">Doctor</a></button><br><br>
           <button class="bt"><a href="patientview.php" class="link">Patient</a></button><br><br>
		   <button class="bt"><a href="doctor_registration.php" class="link">Add Doctor</a></button><br><br>
           <button class="bt"><a href="#" class="link">Logout</a></li>
<?php include("footer.php");?>
