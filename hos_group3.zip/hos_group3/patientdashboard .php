<?php include("header.php");?>
<!-- Patient Dashboard
  *Author:Ebin
-->
<div class="btd">
<button class="bt"><a href="search_doc.php" class="link">SEARCH FOR DOCTOR</a></button><br><br>
<button class="bt"><a href="search_doc.php" class="link">BOOK AN APPOINMENT</a></button><br><br>
<button class="bt"><a href="#" class="link">MANAGE APPOINMENT</a></button><br><br>
<button class="bt"><a href="#" class="link">VIEW RECORDS</a></button><br><br>
</div>
<?php include("footer.php");?>
